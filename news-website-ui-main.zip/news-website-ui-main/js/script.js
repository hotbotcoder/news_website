const preloader = document.querySelector(".preloader");

window.addEventListener('load', () => {
    preloader.remove();
})