# news-website-ui

This project is the UI of an anonymous **news website**. It is created with HTML, CSS and a bit of JS. JS is just for the preloader part.

Its layout is designed with the combination of css-flex and css-grid.

## site link

By [Clicking Me](https://msarmadqadeer.github.io/news-website-ui/) you'll see the live version of this project.

## screen

![](./images/screen.png)
